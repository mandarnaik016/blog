import re


def replace_syntax_in_file(file_path):
    # Read the contents of the file

    with open(file_path, "r") as file:
        content = file.read()
    # Define the pattern to search for and the replacement string

    pattern = r"\[(.*?)\]"  # This regex captures anything inside brackets

    def replace_function(match):
        filename = match.group(1)  # Get the matched filename
        # Construct the replacement string

        new_string = (
            f'{{% include lazyimg.html img_src="../assets/img/evasion/msi-abuse/lowly/{filename[:-4]}.jpeg" '
            f'img_datasrc="../assets/img/evasion/msi-abuse/{filename}" '
            f'img_alt="{filename[:-4].replace("-", " ")}" %}}'
        )
        return new_string

    # Perform the replacement

    updated_content = re.sub(pattern, replace_function, content)

    # Write the updated content back to the file

    with open(file_path, "w") as file:
        file.write(updated_content)


if __name__ == "__main__":
    # Change 'input_file.txt' to your actual input file path

    file_path = "input.txt"
    replace_syntax_in_file(file_path)
    print(f"Replacements completed in {file_path}")
